package com.service;

public interface UserService {

}
